import subprocess as sp

def handler(event, context):
	output = sp.check_output("./binary")
	return {'output':output}
